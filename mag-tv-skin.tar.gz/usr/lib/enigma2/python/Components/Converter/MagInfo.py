# -*- coding: utf-8 -*-
#
# MagInfo - conversor do skin MAG-TV (OpenATV 6.x, Python 2)
#
#   Number     numero do canal (do servico atual ou do selecionado na lista)
#   TimeRange  "20:00 - 21:00" do evento
#   Remaining  "+25 min" que faltam ao evento atual
#   Next       "21:00  Titulo" do evento seguinte (via cache EPG)
#   Provider   fornecedor do servico (funciona na lista de canais e na infobar)
#
# Qualquer erro devolve texto vazio: o skin nunca rebenta por causa deste conversor.

from time import localtime, strftime, time

from Components.Converter.Converter import Converter
from Components.Converter.Poll import Poll
from Components.Element import cached
from enigma import eServiceReference, eServiceCenter, eEPGCache, iServiceInformation

_NUMS = {"time": 0, "map": None}
TV_ROOT = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet'


def _norm(refstr):
	return ":".join(p.upper() for p in refstr.split(":")[:10])


def _scan_numbers():
	"""Numeracao a partir dos bouquets de TV (so usada se o servico nao trouxer numero)."""
	now = time()
	if _NUMS["map"] is not None and now - _NUMS["time"] < 600:
		return _NUMS["map"]
	nums = {}
	n = 0
	try:
		sc = eServiceCenter.getInstance()
		blist = sc.list(eServiceReference(TV_ROOT))
		for b in (blist and blist.getContent("R", False) or []):
			if not (b.flags & eServiceReference.isDirectory):
				continue
			slist = sc.list(b)
			for s in (slist and slist.getContent("R", False) or []):
				if s.flags & (eServiceReference.isMarker | eServiceReference.isDirectory):
					continue
				n += 1
				nums.setdefault(_norm(s.toString()), n)
	except Exception:
		pass
	_NUMS["time"] = now
	_NUMS["map"] = nums
	return nums


class MagInfo(Poll, Converter, object):
	NUMBER, TIMERANGE, REMAINING, NEXT, PROVIDER = range(5)

	def __init__(self, type):
		Converter.__init__(self, type)
		Poll.__init__(self)
		self.type = {"Number": self.NUMBER, "TimeRange": self.TIMERANGE,
			"Remaining": self.REMAINING, "Next": self.NEXT,
			"Provider": self.PROVIDER}.get(type.strip(), self.TIMERANGE)
		if self.type in (self.REMAINING, self.NEXT):
			self.poll_interval = 30000
			self.poll_enabled = True

	def _ref(self):
		src = self.source
		svc = getattr(src, "service", None)
		if isinstance(svc, eServiceReference):           # ServiceEvent (lista de canais)
			return svc
		ref = getattr(src, "serviceref", None)           # session.CurrentService
		if ref is not None:
			return ref
		info = svc and svc.info()
		if info:
			s = info.getInfoString(iServiceInformation.sServiceref)
			if s:
				return eServiceReference(s)
		return None

	def _number(self):
		ref = self._ref()
		if ref is None:
			return ""
		n = 0
		try:
			n = ref.getChannelNum()
		except Exception:
			n = 0
		if not n:
			n = _scan_numbers().get(_norm(ref.toString()), 0)
		return n and str(n) or ""

	def _next(self):
		ref = self._ref()
		if ref is None:
			return ""
		ev = eEPGCache.getInstance().lookupEventTime(ref, -1, 1)
		if not ev:
			return ""
		return "%s  %s" % (strftime("%H:%M", localtime(ev.getBeginTime())), ev.getEventName() or "")

	def _provider(self):
		src = self.source
		svc = getattr(src, "service", None)
		if isinstance(svc, eServiceReference):
			# lista de canais: informacao estatica -> getInfoString(ref, what)
			info = src.info
			return info and info.getInfoString(svc, iServiceInformation.sProvider) or ""
		info = svc and svc.info()                         # servico a tocar
		return info and info.getInfoString(iServiceInformation.sProvider) or ""

	@cached
	def getText(self):
		try:
			if self.type == self.PROVIDER:
				return self._provider()
			if self.type == self.NUMBER:
				return self._number()
			if self.type == self.NEXT:
				return self._next()
			ev = getattr(self.source, "event", None)
			if not ev:
				return ""
			begin, dur = ev.getBeginTime(), ev.getDuration()
			if self.type == self.TIMERANGE:
				return "%s - %s" % (strftime("%H:%M", localtime(begin)), strftime("%H:%M", localtime(begin + dur)))
			if self.type == self.REMAINING:
				now = int(time())
				if begin > now:
					return ""
				return "+%d min" % max(0, (begin + dur - now) // 60)
		except Exception:
			return ""
		return ""

	text = property(getText)
